#include <iostream>
#include<bits/stdc++.h>

using namespace std;

struct Node 
{ 
    int data; 
    struct Node* left, *right; 
    Node(int data) 
    { 
        this->data = data; 
        left = right = NULL; 
    } 
};

// void levelOrderTraversal(Node *root){
//     queue<Node *> q;
//     q.push(root);
//     while(!q.empty()){
//         Node *temp = q.front();
//         q.pop();
//         cout<<temp->data<<" ";
//         if(temp->left)
//             q.push(temp->left);
//         if(temp->right)
//             q.push(temp->right);
//     }
// }


// void inOrder(Node *root){
//     if(root){
//         inOrder(root->left);
//         cout<<root->data<<" ";
//         inOrder(root->right);
//     }
// }


// void inOrderWithoutRecursion(Node *root){
//     stack<Node *>s;
//     while(1){
//         while(root){
//             s.push(root);
//             root = root->left;
//         }
//         if(s.empty())
//             break;
//         root = s.top();
//         s.pop();
//         cout<<root->data<<" ";
//         root = root->right;
//     }
// }


// void postOrder(Node *root){
//     if(root){
//         postOrder(root->left);
//         postOrder(root->right);
//         cout<<root->data<<" ";
//     }
// }


// void postOrderWithoutRecursion(Node *root){
//     stack<Node *> s;
//     do{
//         while(root){
//             if(root->right)
//                 s.push(root->right);
//             s.push(root);
//             root = root->left;
//         }
//         root = s.top();
//         s.pop();
//         if(root->right && s.top()== root->right){
//             s.pop();
//             s.push(root);
//             root = root->right;
//         }
//         else{
//             cout<<root->data<<" ";
//             root = NULL;
//         }
        
//     }while(!s.empty());
// }


// void preOrderWithoutRecursion(Node *root){
//     stack<Node *> s;
//     s.push(root);
//     while(!s.empty()){
//         Node *temp = s.top();
//         s.pop();
//         cout<<temp->data<<" ";
//         if(temp->right)
//             s.push(root->right);
//         if(temp->left)
//             s.push(root->left);
//     }
// }


// void preOrder(Node *root){
//     if(root){
//         cout<<root->data<<" ";
//         preOrder(root->left);
//         preOrder(root->right);
//     }
// }

int findMax(Node *root){
    int max = INT_MIN;
    if(root!=NULL){
        int root_val = root->data;
        int left = findMax(root->left);
        int right = findMax(root->right);
        max = (left>right?left:right);
        max = max>root_val?max:root_val;
    }
    return max;
}
int findMaxWithoutRecursion(Node *root){
    queue<Node *> q;
    q.push(root);
    int max = INT_MIN;
    while(!q.empty()){
        Node *temp = q.front();
        q.pop();
        max = max>temp->data?max:temp->data; 
        if(temp->left)
            q.push(temp->left);
        if(temp->right)
            q.push(temp->right);
    }
    return max;
} 
int searchElement(Node *root,int data){
    if(root == NULL)
        return 0;
    if(root->data == data)
        return 1;
    return searchElement(root->left,data);
    return searchElement(root->right,data);
}

int searchElementWithoutRecursion(Node *root,int data){
    queue<Node *> q;
    q.push(root);
    while(!q.empty()){
        Node *temp = q.front();
        q.pop();
        if(temp->data == data)
            return 1;
        if(temp->left)
            q.push(temp->left);
        if(temp->right)
            q.push(temp->right);
    }
    return 0;
}
int main()
{
   
    struct Node *root = new Node(1); 
    root->left = new Node(2); 
    root->right = new Node(13); 
    root->left->left = new Node(4); 
    root->left->right = new Node(5);  
    
    //cout<<findMax(root);
    //cout<<findMaxWithoutRecursion(root);
    
    cout<<searchElement(root,4);
    cout<<searchElementWithoutRecursion(root,4);
    // cout<<endl<<"INORDER TRAVERSAL"<<endl;
    // inOrder(root);
    
    // cout<<endl<<"INORDER TRAVERSAL WITHOUT RECURSION"<<endl;
    // inOrderWithoutRecursion(root);
    
    // cout<<endl<<"PREORDER TRAVERSAL"<<endl;
    // preOrder(root);
    
    // cout<<"PREORDER TRAVERSAL WITHOUT RECURSION"<<endl;
    // preOrderWithoutRecursion(root);
    
    //cout<<endl<<"POSTORDER TRAVERSAL WITHOUT RECURSION"<<endl;
    //postOrderWithoutRecursion(root);
    
    // cout<<endl<<"LEVELORDER TRAVERSAL"<<endl;
    // levelOrderTraversal(root);
    
    
   return 0;
}